﻿namespace MilitaryElite.Interfaces
{
    public interface ISpy
    {
        public int CodeNumber { get; }
    }
}
