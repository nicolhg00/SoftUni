﻿using System;

namespace BoxOfT
{
    class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
