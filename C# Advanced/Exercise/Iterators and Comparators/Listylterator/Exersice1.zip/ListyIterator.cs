﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Listylterator
{
    public class ListyIterator<T>
    {
        private List<T> colection;
        private int currIndex;

        public ListyIterator(params T[] data)
        {
            colection = new List<T>(data);
            currIndex = 0;
        }

        public List<T> List => colection;
        public bool Move()
        {
            bool canMove = HasNext();
            if (canMove)
            {
                currIndex++;
            }
            return canMove;
        }

        public void Print()
        {
            if (colection.Count == 0)
            {
                throw new InvalidOperationException("Invalid Operation!");
            }
            Console.WriteLine($"{colection[currIndex]}");
        }

        public bool HasNext() => currIndex < colection.Count - 1;
    }
}
