﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-G75N68F;Database=TeisterMask;Trusted_Connection=True";
    }
}
