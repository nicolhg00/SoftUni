﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=DESKTOP-G75N68F;Database=VaporStore;Trusted_Connection=True";
	}
}