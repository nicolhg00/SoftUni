﻿namespace BookShop.DataProcessor.ImportDto
{
    public class ImportAuthorsBookDto
    {
        public int? Id { get; set; }
    }
}