﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=DESKTOP-G75N68F;Database=BookShop;Integrated Security=True;";
    }
}
