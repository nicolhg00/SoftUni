﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Dtos.Input
{
    public class CategoriesInputDto
    {
        public string Name { get; set; }

      
    }
}
