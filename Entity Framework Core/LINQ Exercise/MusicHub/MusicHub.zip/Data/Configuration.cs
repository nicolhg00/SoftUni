﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-G75N68F;Database=MusicHub;Trusted_Connection=True";
    }
}
